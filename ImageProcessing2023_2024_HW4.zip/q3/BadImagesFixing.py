# Student_Name1, Student_ID1
# Student_Name2, Student_ID2

# Please replace the above comments with your names and ID numbers in the same format.

import numpy as np
from numpy.fft import fft2, ifft2, fftshift, ifftshift
import cv2
import matplotlib.pyplot as plt


def clean_baby(im):
	# Your code goes here

def clean_windmill(im):
	# Your code goes here

def clean_watermelon(im):
	# Your code goes here

def clean_umbrella(im):
	# Your code goes here

def clean_USAflag(im):
	# Your code goes here

def clean_house(im):
	# Your code goes here

def clean_bears(im):
	# Your code goes here


